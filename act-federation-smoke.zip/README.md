# ACT Federation Smoke Test

A one-command smoke test that **moves value** across your federated ACT societies and
verifies the result from both nodes.

## Contents

- `scripts/fed_transfer.sh` — end-to-end script (create keys, fund, transfer, verify).
- `config.env.example` — example environment config to copy/edit.
- `README.md` — this file.

## Prerequisites

- Two ACT nodes already federated and syncing.
- `racecar-webd` binary available on the machine where you run the script.
- `curl`, `jq` installed.
- Chain ID and RPC endpoints for both societies.

## Quick Start

```bash
# 1) copy example config and edit if needed
cp config.env.example config.env

# 2) run the smoke test
bash scripts/fed_transfer.sh
```

The script prints a **RESULT** block with pass/fail and shows balances from both nodes.

## Environment Variables

You may set these either in your shell or via `config.env` in this folder.

- `BIN`       — path to the racecar-webd binary (default: `/home/dp/.go/bin/racecar-webd`)
- `CHAIN_ID`  — chain-id (default: `act-web4`)
- `S1_HOME`   — homedir for Society 1 (default: `./society1`)
- `S2_HOME`   — homedir for Society 2 (default: `./society2`)
- `S1_RPC`    — RPC for Society 1 (default: `http://10.0.0.72:26657`)
- `S2_RPC`    — RPC for Society 2 (default: `http://10.0.0.146:26657`)
- `SENDER_KEY`— key name in S1 home (default: `alice`)
- `RECIP_KEY` — key name in S2 home (default: `bob`)
- `AMOUNT`    — base units to send (default: `12345`)

## Notes

- The script auto-discovers the base denom from `denom-metadata` and falls back to `uact`.
- If the sender has no balance, it attempts to fund from a local key in S1.
- Uses `--broadcast-mode block` for deterministic confirmation.
- All output is pretty-printed for quick visual checks.
