#!/usr/bin/env bash
set -euo pipefail

# Load optional config.env from repo root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
if [[ -f "$ROOT_DIR/config.env" ]]; then
  # shellcheck source=/dev/null
  source "$ROOT_DIR/config.env"
fi

# Defaults
BIN="${BIN:-/home/dp/.go/bin/racecar-webd}"
CHAIN_ID="${CHAIN_ID:-act-web4}"

S1_HOME="${S1_HOME:-./society1}"
S2_HOME="${S2_HOME:-./society2}"

S1_RPC="${S1_RPC:-http://10.0.0.72:26657}"
S2_RPC="${S2_RPC:-http://10.0.0.146:26657}"

SENDER_KEY="${SENDER_KEY:-alice}"
RECIP_KEY="${RECIP_KEY:-bob}"
AMOUNT="${AMOUNT:-12345}"

KEYRING="test"
JQ=${JQ:-jq}
CURL=${CURL:-curl}

# Helpers
hr() { printf '%*s\n' "${1:-60}" '' | tr ' ' -; }
say() { printf "\n\033[1m%s\033[0m\n" "$*"; }

need() {
  command -v "$1" >/dev/null 2>&1 || { echo "Missing dependency: $1"; exit 1; }
}

need "$BIN"
need "$JQ"
need "$CURL"

say "ACT Federation Smoke Test"
hr

say "1) RPC sanity"
S1_H=$($CURL -s "$S1_RPC/status" | $JQ -r '.result.sync_info.latest_block_height')
S2_H=$($CURL -s "$S2_RPC/status" | $JQ -r '.result.sync_info.latest_block_height')
echo "S1 height: $S1_H"
echo "S2 height: $S2_H"

say "2) Discover base denom"
DENOM="$($BIN q bank denom-metadata --node "$S1_RPC" -o json 2>/dev/null | $JQ -r '.metadatas[0].base // empty')"
if [[ -z "${DENOM}" || "${DENOM}" == "null" ]]; then
  DENOM="uact"
  echo "Falling back to DENOM=${DENOM}"
else
  echo "DENOM=${DENOM}"
fi

say "3) Ensure keys exist"
$BIN keys show "$SENDER_KEY" --home "$S1_HOME" --keyring-backend "$KEYRING" >/dev/null 2>&1 || \
  $BIN keys add "$SENDER_KEY" --home "$S1_HOME" --keyring-backend "$KEYRING" >/dev/null
$BIN keys show "$RECIP_KEY" --home "$S2_HOME" --keyring-backend "$KEYRING" >/dev/null 2>&1 || \
  $BIN keys add "$RECIP_KEY" --home "$S2_HOME" --keyring-backend "$KEYRING" >/dev/null

SENDER=$($BIN keys show -a "$SENDER_KEY" --home "$S1_HOME" --keyring-backend "$KEYRING")
RECIP=$($BIN keys show -a "$RECIP_KEY" --home "$S2_HOME" --keyring-backend "$KEYRING")
echo "SENDER   = $SENDER"
echo "RECIPIENT= $RECIP"

say "4) Ensure sender funded"
BAL_JSON="$($BIN q bank balances "$SENDER" --node "$S1_RPC" -o json 2>/dev/null || echo '{}')"
BAL=$(
  echo "$BAL_JSON" \
  | $JQ -r --arg D "$DENOM" '.balances[]? | select(.denom==$D) | .amount' \
  | head -n1
)

if [[ -z "${BAL}" ]]; then BAL="0"; fi
echo "Sender balance before: ${BAL} ${DENOM}"

if [[ "$BAL" -lt 1000 ]]; then
  say "Funding sender (insufficient balance)"
  # pick first available local key as funder
  FUNDER=$($BIN keys list --home "$S1_HOME" --keyring-backend "$KEYRING" -o json \
    | $JQ -r '.[0].address')
  echo "Funder: $FUNDER"
  $BIN tx bank send "$FUNDER" "$SENDER" "1000000${DENOM}" \
    --home "$S1_HOME" --keyring-backend "$KEYRING" \
    --chain-id "$CHAIN_ID" --node "$S1_RPC" \
    --gas auto --gas-adjustment 1.3 --gas-prices "0.025${DENOM}" \
    --broadcast-mode block -y >/dev/null
  echo "Funded."
fi

say "5) Execute transfer ${AMOUNT}${DENOM}"
TX_JSON="$($BIN tx bank send "$SENDER" "$RECIP" "${AMOUNT}${DENOM}" \
  --home "$S1_HOME" --keyring-backend "$KEYRING" \
  --chain-id "$CHAIN_ID" --node "$S1_RPC" \
  --gas auto --gas-adjustment 1.3 --gas-prices "0.025${DENOM}" \
  --broadcast-mode block -y -o json)"
TX=$(echo "$TX_JSON" | $JQ -r '.txhash // .txhash')
echo "TXHASH: $TX"

say "6) Verify from both nodes"
CODE1=$($BIN q tx "$TX" --node "$S1_RPC" -o json | $JQ -r '.code // 0')
CODE2=$($BIN q tx "$TX" --node "$S2_RPC" -o json | $JQ -r '.code // 0')
echo "S1 tx code: $CODE1"
echo "S2 tx code: $CODE2"

say "Recipient balances"
echo "- via S1:"
$BIN q bank balances "$RECIP" --node "$S1_RPC" | sed 's/^/  /'
echo "- via S2:"
$BIN q bank balances "$RECIP" --node "$S2_RPC" | sed 's/^/  /'

PASS="false"
if [[ "$CODE1" == "0" && "$CODE2" == "0" ]]; then
  PASS="true"
fi

hr
if [[ "$PASS" == "true" ]]; then
  echo "RESULT: ✅ PASS — Transaction finalized on both societies."
else
  echo "RESULT: ❌ FAIL — Check node sync, fees, or RPC endpoints."
fi
hr

say "Sync snapshot"
echo -n "S1 height: "; $CURL -s "$S1_RPC/status" | $JQ -r '.result.sync_info.latest_block_height'
echo -n "S2 height: "; $CURL -s "$S2_RPC/status" | $JQ -r '.result.sync_info.latest_block_height'
echo -n "S1 peers:  "; $CURL -s "$S1_RPC/net_info" | $JQ -r '.result.n_peers'
echo -n "S2 peers:  "; $CURL -s "$S2_RPC/net_info" | $JQ -r '.result.n_peers'

echo
echo "Done."
